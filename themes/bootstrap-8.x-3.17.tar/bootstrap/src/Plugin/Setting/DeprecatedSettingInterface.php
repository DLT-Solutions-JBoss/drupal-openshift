<?php

namespace Drupal\bootstrap\Plugin\Setting;

/**
 * Interface DeprecatedSettingInterface.
 */
interface DeprecatedSettingInterface {
}
